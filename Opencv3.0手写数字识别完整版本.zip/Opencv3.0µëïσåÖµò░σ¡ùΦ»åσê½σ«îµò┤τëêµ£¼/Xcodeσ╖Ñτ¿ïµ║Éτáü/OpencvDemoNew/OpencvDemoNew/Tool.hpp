
#include <iostream>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

#include <opencv2/opencv.hpp>

using namespace  std;
using namespace cv;
using namespace ml;

namespace Tool {
    
    
    long getTimeLabel();
    void drawRectangle(Mat& img,Rect box);
    vector<string> listFiles(string dir);
    
    
    
    
    
    void printTime(){
        time_t tt = time(NULL);//这句返回的只是一个时间cuo
        tm* t= localtime(&tt);
        printf("%d-%02d-%02d %02d:%02d:%02d\n",
               t->tm_year + 1900,
               t->tm_mon + 1,
               t->tm_mday,
               t->tm_hour,
               t->tm_min,
               t->tm_sec);
        
        printf("now:%li",getTimeLabel());
    }
    
    long getTimeLabel(){
        time_t now_time;
        now_time = time(NULL);
        
        return now_time;
    }
    
    
    void drawRectangle(Mat& img,Rect box){
        
        rectangle(img, box.tl(), box.br(), Scalar(200,88,88));
        
    }
    
    
    vector<string> listFiles(string dirRoot){
        
        vector<string> subfiles;
        DIR    *dir;
        struct  dirent    *ptr;
        dir = opendir(dirRoot.c_str()); ///open the dir
        while((ptr = readdir(dir)) != NULL) ///read the list of this dir
        {
//            .
//            ..
//            .DS_Store
            
            string fname=string(ptr->d_name);
            if("."!=fname && ".."!=fname && ".DS_Store"!=fname){
                 subfiles.push_back(ptr->d_name);
            }
  
        }
        closedir(dir);
        return subfiles;
    }
    
    
}
